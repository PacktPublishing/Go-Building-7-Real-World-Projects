ssh ben@159.203.4.252
go get -u github.com/golang/example/outyet
supervisorctl restart goprojetcs
logout
