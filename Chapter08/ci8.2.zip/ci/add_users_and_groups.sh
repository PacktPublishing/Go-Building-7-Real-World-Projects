sudo adduser ben
# You'll be prompted to add a password and some info
sudo addgroup --system goprojects
sudo adduser ben goprojects

logout

# You should log back in as <username>@<ip_address>
groups
